import { useState, useRef, useEffect, useCallback } from 'react';

// --- TypeScript Definitions for Web Speech API ---
// This block adds TypeScript definitions for the Web Speech API, which are not
// included by default in many TypeScript projects. This resolves compilation
// errors related to `SpeechRecognition` and associated types.

// This represents a single word or phrase recognized by the speech recognition service.
interface SpeechRecognitionAlternative {
  readonly transcript: string;
  readonly confidence: number;
}

// This represents a single recognition match, which may be final or intermediate.
interface SpeechRecognitionResult {
  readonly isFinal: boolean;
  readonly length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
}

// A list of SpeechRecognitionResult objects.
interface SpeechRecognitionResultList {
  readonly length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

// The event fired when the speech recognition service returns a result.
interface SpeechRecognitionEvent extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultList;
}

// The main interface for the speech recognition service.
interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;

  onend: ((this: SpeechRecognition, ev: Event) => any) | null;
  
  // Overload addEventListener for specific event types used in this hook
  addEventListener(type: 'result', listener: (this: SpeechRecognition, ev: SpeechRecognitionEvent) => any, options?: boolean | AddEventListenerOptions): void;
  addEventListener(type: 'end', listener: (this: SpeechRecognition, ev: Event) => any, options?: boolean | AddEventListenerOptions): void;
  addEventListener(type: string, listener: EventListenerOrEventListenerObject, options?: boolean | AddEventListenerOptions): void;

  // Overload removeEventListener for specific event types used in this hook
  removeEventListener(type: 'result', listener: (this: SpeechRecognition, ev: SpeechRecognitionEvent) => any, options?: boolean | EventListenerOptions): void;
  removeEventListener(type: 'end', listener: (this: SpeechRecognition, ev: Event) => any, options?: boolean | EventListenerOptions): void;
  removeEventListener(type: string, listener: EventListenerOrEventListenerObject, options?: boolean | EventListenerOptions): void;
}

// The constructor for the SpeechRecognition object.
interface SpeechRecognitionStatic {
  new(): SpeechRecognition;
}

// We create a new interface extending `Window` to include the speech recognition constructors.
// This avoids polluting the global namespace. `webkitSpeechRecognition` is for browser compatibility.
interface IWindow extends Window {
  SpeechRecognition: SpeechRecognitionStatic;
  webkitSpeechRecognition: SpeechRecognitionStatic;
}

// --- End of TypeScript Definitions ---

const getSpeechRecognition = () => {
  const SpeechRecognitionConstructor = (window as unknown as IWindow).SpeechRecognition || (window as unknown as IWindow).webkitSpeechRecognition;
  if (SpeechRecognitionConstructor) {
    return new SpeechRecognitionConstructor();
  }
  return null;
};

export const useSpeech = () => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState('');
  
  const recognitionRef = useRef<SpeechRecognition | null>(getSpeechRecognition());
  const finalTranscriptRef = useRef<string>('');

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  }, [isListening]);
  
  const resetTranscript = useCallback(() => {
    finalTranscriptRef.current = '';
    setTranscript('');
  }, []);

  const startListening = useCallback(() => {
    if (recognitionRef.current && !isListening) {
      // Don't reset transcript here, allow appending
      recognitionRef.current.start();
      setIsListening(true);
    }
  }, [isListening]);

  useEffect(() => {
    const recognition = recognitionRef.current;
    if (!recognition) {
      console.warn('Speech Recognition is not supported in this browser.');
      return;
    }

    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    const handleResult = (event: SpeechRecognitionEvent) => {
      let interimTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscriptRef.current += event.results[i][0].transcript + ' ';
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }
      setTranscript(finalTranscriptRef.current + interimTranscript);
    };
    
    const handleEnd = () => {
      setIsListening(false);
    };

    recognition.addEventListener('result', handleResult);
    recognition.addEventListener('end', handleEnd);

    return () => {
      recognition.removeEventListener('result', handleResult);
      recognition.removeEventListener('end', handleEnd);
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const speak = (text: string, onEnd?: () => void) => {
    if (!window.speechSynthesis || !text) {
        console.warn('Speech Synthesis not supported or text is empty');
        if(onEnd) onEnd();
        return;
    }
    // Cancel any previous speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => {
      setIsSpeaking(false);
      if(onEnd) onEnd();
    };
    utterance.onerror = (event) => {
        console.error("SpeechSynthesis Error", event);
        setIsSpeaking(false);
        if(onEnd) onEnd();
    };
    window.speechSynthesis.speak(utterance);
  };

  return { isListening, transcript, startListening, stopListening, speak, isSpeaking, resetTranscript };
};
