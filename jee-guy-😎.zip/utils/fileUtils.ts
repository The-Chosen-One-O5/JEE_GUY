export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      // result is "data:mime/type;base64,..."
      // we just want the base64 part
      const resultString = reader.result as string;
      const base64String = resultString.split(',')[1];
      if (base64String) {
        resolve(base64String);
      } else {
        // Handle cases where the split might fail or result is empty
        reject(new Error("Failed to extract Base64 from file reader result."));
      }
    };
    reader.onerror = error => reject(error);
  });
};
