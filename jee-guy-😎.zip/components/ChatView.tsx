
import React, { useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { ChatMessage as ChatMessageData, Attachment } from '../types';
import MainInput from './MainInput';
import { PlusIcon, HistoryIcon, UserIcon, PaperclipIcon } from './icons';

interface SpeechProps {
    isListening: boolean;
    transcript: string;
    startListening: () => void;
    stopListening: () => void;
    resetTranscript: () => void;
}

interface ChatViewProps {
    messages: ChatMessageData[];
    isLoading: boolean;
    error: string | null;
    onSendMessage: (message: string, files: File[]) => void;
    onNewChat: () => void;
    onShowHistory: () => void;
    onStartCall: () => void;
    speechProps: SpeechProps;
}

const TypingIndicator: React.FC = () => (
    <div className="flex items-center space-x-2 self-start my-4">
        <div className="w-2 h-2 bg-brand-muted rounded-full animate-pulse [animation-delay:-0.3s]"></div>
        <div className="w-2 h-2 bg-brand-muted rounded-full animate-pulse [animation-delay:-0.15s]"></div>
        <div className="w-2 h-2 bg-brand-muted rounded-full animate-pulse"></div>
    </div>
);

const AttachmentPreview: React.FC<{ attachment: Attachment }> = ({ attachment }) => {
    if (attachment.type.startsWith('image/')) {
        return (
            <div className="mt-2">
                <img src={attachment.url} alt={attachment.name} className="max-w-xs max-h-64 rounded-lg object-cover border border-brand-border" />
            </div>
        )
    }
    return (
        <div className="mt-2 flex items-center gap-2 bg-brand-surface p-2 rounded-lg border border-brand-border max-w-xs">
            <PaperclipIcon className="w-5 h-5 flex-shrink-0 text-brand-muted" />
            <span className="text-sm truncate text-brand-subtle">{attachment.name}</span>
        </div>
    )
}

const ChatView: React.FC<ChatViewProps> = ({ messages, isLoading, error, onSendMessage, onNewChat, speechProps, onShowHistory, onStartCall }) => {
    const bottomRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if(isLoading) {
            bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
        }
    }, [isLoading, messages.length]);

    const lastUserMessage = messages.filter(m => m.role === 'user').pop();

    return (
        <div className="flex flex-col h-screen bg-brand-bg text-brand-text font-sans">
             <header className="absolute top-0 left-0 right-0 p-4 sm:p-6 flex justify-between items-center z-10">
                <button onClick={onNewChat} className="p-2 rounded-full bg-brand-surface/80 backdrop-blur-sm hover:bg-brand-surface-light transition-colors" aria-label="New Chat">
                    <PlusIcon className="w-6 h-6" />
                </button>
                <div className="flex items-center space-x-2">
                    <button onClick={onShowHistory} className="p-2 rounded-full bg-brand-surface/80 backdrop-blur-sm hover:bg-brand-surface transition-colors" aria-label="History">
                        <HistoryIcon className="w-6 h-6" />
                    </button>
                    <button className="p-2 rounded-full bg-brand-surface/80 backdrop-blur-sm hover:bg-brand-surface transition-colors" aria-label="User Profile">
                        <UserIcon className="w-6 h-6" />
                    </button>
                </div>
            </header>

            <main className="flex-1 overflow-y-auto pt-24">
                <div className="max-w-3xl mx-auto px-4 sm:px-6">
                    {messages.map((msg) => (
                        <div key={msg.id}>
                            {msg.role === 'model' && (
                                <div className="prose prose-invert prose-p:my-3 prose-headings:my-4 prose-pre:bg-brand-surface max-w-none text-brand-text">
                                  <ReactMarkdown>{msg.text || '...'}</ReactMarkdown>
                                </div>
                            )}
                        </div>
                    ))}
                    
                    {isLoading && <TypingIndicator />}
                    {error && <div className="text-center text-red-500 py-4">{error}</div>}

                    <div className="my-16">
                        <MainInput 
                            onSendMessage={onSendMessage} 
                            isLoading={isLoading} 
                            speechProps={{
                                isRecording: speechProps.isListening,
                                onMicClick: speechProps.isListening ? speechProps.stopListening : speechProps.startListening,
                                initialInput: speechProps.transcript,
                                resetTranscript: speechProps.resetTranscript
                            }}
                            onStartCall={onStartCall}
                        />
                    </div>
                    <div ref={bottomRef} />
                </div>
            </main>
        </div>
    );
};

export default ChatView;
