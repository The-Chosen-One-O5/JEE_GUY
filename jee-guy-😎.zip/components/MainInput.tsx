import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
    LaptopIcon, 
    ChevronDownIcon, 
    GridIcon, 
    TelescopeIcon, 
    MicIcon, 
    PaperclipIcon, 
    ArrowUpIcon,
    XIcon
} from './icons';

interface MainInputProps {
  onSendMessage: (message: string, files: File[]) => void;
  isLoading: boolean;
  speechProps: {
    isRecording: boolean;
    onMicClick: () => void;
    initialInput: string;
    resetTranscript: () => void;
  };
  onStartCall: () => void;
}

const AttachmentChip: React.FC<{ file: File, onRemove: () => void }> = ({ file, onRemove }) => {
    return (
        <div className="flex items-center gap-2 bg-brand-surface-light p-2 rounded-lg">
            <PaperclipIcon className="w-4 h-4 text-brand-subtle" />
            <span className="text-sm text-brand-text truncate max-w-32">{file.name}</span>
            <button onClick={onRemove} className="p-0.5 rounded-full hover:bg-brand-border">
                <XIcon className="w-3 h-3 text-brand-muted" />
            </button>
        </div>
    )
}

const MainInput: React.FC<MainInputProps> = ({ onSendMessage, isLoading, speechProps, onStartCall }) => {
  const [input, setInput] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (speechProps.initialInput) {
      setInput(speechProps.initialInput);
    }
  }, [speechProps.initialInput]);

  useEffect(() => {
    if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
        textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [input, files]);

  const handleAddFiles = (newFiles: FileList | null) => {
    if (newFiles) {
        setFiles(prev => [...prev, ...Array.from(newFiles)]);
    }
  }

  const handleRemoveFile = (indexToRemove: number) => {
    setFiles(prev => prev.filter((_, index) => index !== indexToRemove));
  }

  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    if (e.clipboardData.files.length > 0) {
        e.preventDefault();
        handleAddFiles(e.clipboardData.files);
    }
  };

  const handleSubmit = () => {
    if ((input.trim() || files.length > 0) && !isLoading) {
      onSendMessage(input, files);
      setInput('');
      setFiles([]);
      speechProps.resetTranscript();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSubmit();
    }
  }

  return (
    <div className="w-full bg-brand-surface border border-brand-border rounded-2xl p-4 flex flex-col gap-4 shadow-2xl shadow-black/30">
        {files.length > 0 && (
            <div className="flex flex-wrap gap-2">
                {files.map((file, index) => (
                    <AttachmentChip key={index} file={file} onRemove={() => handleRemoveFile(index)} />
                ))}
            </div>
        )}
        <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            placeholder="Ask a question, or paste an image..."
            className="bg-transparent w-full resize-none outline-none text-lg text-brand-text placeholder-brand-muted max-h-48"
            rows={1}
            disabled={isLoading}
        />
        <div className="flex justify-between items-center">
            <div className="flex items-center gap-2 flex-wrap">
                <button className="flex items-center gap-2 px-3 py-1.5 bg-brand-surface-light hover:bg-brand-border transition-colors rounded-lg text-sm text-brand-text">
                    <LaptopIcon className="w-4 h-4" /> Academic <ChevronDownIcon className="w-4 h-4 opacity-50" />
                </button>
                <button className="flex items-center gap-2 p-1.5 bg-brand-surface-light hover:bg-brand-border transition-colors rounded-lg text-sm text-brand-text">
                    <GridIcon className="w-4 h-4" /> <ChevronDownIcon className="w-4 h-4 opacity-50" />
                </button>
                <button onClick={onStartCall} className="flex items-center gap-2 px-3 py-1.5 bg-brand-surface-light hover:bg-brand-border transition-colors rounded-lg text-sm text-brand-text">
                    <TelescopeIcon className="w-4 h-4" /> Extreme
                </button>
            </div>
            <div className="flex items-center gap-2">
                <button 
                    onClick={speechProps.onMicClick}
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${speechProps.isRecording ? 'bg-red-500 text-white' : 'bg-brand-surface-light hover:bg-brand-border text-brand-muted'}`}
                    aria-label={speechProps.isRecording ? 'Stop recording' : 'Start recording'}
                >
                    <MicIcon className="w-5 h-5" />
                </button>
                <input type="file" ref={fileInputRef} onChange={(e) => handleAddFiles(e.target.files)} accept="application/pdf,image/*" multiple hidden />
                <button onClick={() => fileInputRef.current?.click()} className="w-10 h-10 rounded-full bg-brand-surface-light hover:bg-brand-border text-brand-muted flex items-center justify-center transition-colors" aria-label="Attach file">
                    <PaperclipIcon className="w-5 h-5" />
                </button>
                <button 
                    onClick={handleSubmit} 
                    disabled={(!input.trim() && files.length === 0) || isLoading}
                    className="w-10 h-10 rounded-full bg-brand-send text-brand-send-text flex items-center justify-center transition-colors disabled:bg-brand-surface-light disabled:text-brand-subtle disabled:cursor-not-allowed"
                    aria-label="Send message"
                >
                    <ArrowUpIcon className="w-5 h-5" />
                </button>
            </div>
        </div>
    </div>
  );
};

export default MainInput;
