import React, { useEffect, useState, useRef } from 'react';
import { XIcon, MicIcon } from './icons';

interface CallViewProps {
  onSendMessage: (message: string) => Promise<void>;
  speech: {
    isListening: boolean;
    transcript: string;
    startListening: () => void;
    stopListening: () => void;
    speak: (text: string, onEnd?: () => void) => void;
    isSpeaking: boolean;
    resetTranscript: () => void;
  };
  onEndCall: () => void;
  latestResponse?: string;
}

const CallView: React.FC<CallViewProps> = ({ onSendMessage, speech, onEndCall, latestResponse }) => {
  const { startListening, stopListening, resetTranscript, speak, transcript, isListening, isSpeaking } = speech;
  const [status, setStatus] = useState<'listening' | 'thinking' | 'speaking' | 'idle'>('idle');
  const transcriptRef = useRef(transcript);
  
  // Keep a ref to the transcript to avoid dependency issues in timeouts
  useEffect(() => {
    transcriptRef.current = transcript;
  }, [transcript]);

  // Main conversation loop logic
  useEffect(() => {
    const handleSpeechEnd = () => {
      if (!isListening && transcriptRef.current.trim()) {
        setStatus('thinking');
        onSendMessage(transcriptRef.current.trim());
        resetTranscript();
      }
    };

    // Use a timeout to detect when the user has stopped speaking
    const timer = setTimeout(handleSpeechEnd, 1500);
    return () => clearTimeout(timer);
  }, [isListening, onSendMessage, resetTranscript]);

  // Effect to speak the latest response from the model
  useEffect(() => {
    if (latestResponse && status === 'thinking') {
      setStatus('speaking');
      speak(latestResponse, () => {
        setStatus('listening');
        startListening();
      });
    }
  }, [latestResponse, speak, startListening, status]);

  // Start listening when the component mounts
  useEffect(() => {
    setStatus('listening');
    startListening();
    // Ensure we stop everything when unmounting
    return () => {
        stopListening();
        window.speechSynthesis.cancel();
    }
  }, [startListening, stopListening]);


  let statusText = "Listening...";
  if (status === 'thinking') statusText = "Thinking...";
  if (status === 'speaking') statusText = "Speaking...";
  if (status === 'idle') statusText = "Initializing...";
  
  return (
    <div className="fixed inset-0 bg-brand-bg z-50 flex flex-col items-center justify-center p-4">
      <button onClick={onEndCall} className="absolute top-4 right-4 p-2 rounded-full hover:bg-brand-surface-light transition-colors">
        <XIcon className="w-6 h-6 text-brand-muted" />
      </button>

      <div className="flex flex-col items-center gap-8">
        <div className={`relative w-48 h-48 rounded-full flex items-center justify-center transition-all duration-300 ${isListening ? 'bg-red-500/20' : 'bg-brand-surface'}`}>
          <div className={`absolute inset-0 rounded-full border-2 border-red-500 scale-100 ${isListening ? 'animate-ping' : ''}`}></div>
          <MicIcon className={`w-20 h-20 transition-colors ${isListening ? 'text-red-500' : 'text-brand-muted'}`} />
        </div>
        <p className="text-2xl font-medium text-brand-text">{statusText}</p>
        <p className="text-lg text-brand-muted h-12 text-center">{transcript}</p>
      </div>
    </div>
  );
};

export default CallView;
