import React from 'react';
import { ChatSession } from '../types';
import { XIcon, HistoryIcon } from './icons';

interface HistoryViewProps {
  sessions: ChatSession[];
  onLoadSession: (sessionId: string) => void;
  onBack: () => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ sessions, onLoadSession, onBack }) => {
  const formatDate = (isoString: string) => {
    return new Date(isoString).toLocaleDateString(undefined, {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  }

  return (
    <div className="fixed inset-0 bg-brand-bg text-brand-text font-sans flex flex-col z-50">
      <header className="flex items-center justify-between p-4 sm:p-6 border-b border-brand-border">
        <div className="flex items-center gap-3">
            <HistoryIcon className="w-6 h-6 text-brand-muted" />
            <h1 className="text-xl font-semibold">Chat History</h1>
        </div>
        <button onClick={onBack} className="p-2 rounded-full hover:bg-brand-surface transition-colors" aria-label="Close History">
          <XIcon className="w-6 h-6" />
        </button>
      </header>
      <main className="flex-1 overflow-y-auto p-4 sm:p-6">
        {sessions.length === 0 ? (
            <div className="text-center text-brand-muted mt-8">No chat history found.</div>
        ) : (
            <ul className="space-y-3">
                {sessions.map(session => (
                    <li key={session.id}>
                        <button 
                            onClick={() => onLoadSession(session.id)}
                            className="w-full text-left p-4 bg-brand-surface hover:bg-brand-surface-light rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <p className="font-semibold truncate">{session.title}</p>
                            <p className="text-sm text-brand-subtle mt-1">{formatDate(session.createdAt)}</p>
                        </button>
                    </li>
                ))}
            </ul>
        )}
      </main>
    </div>
  );
};

export default HistoryView;
