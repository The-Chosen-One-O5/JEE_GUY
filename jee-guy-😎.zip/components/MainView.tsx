
import React from 'react';
import { PlusIcon, HistoryIcon, UserIcon } from './icons';
import MainInput from './MainInput';

interface MainViewProps {
  onSendMessage: (message: string, files: File[]) => void;
  isLoading: boolean;
  speechProps: {
    isListening: boolean;
    transcript: string;
    startListening: () => void;
    stopListening: () => void;
    resetTranscript: () => void;
  };
  onShowHistory: () => void;
  onStartCall: () => void;
  onNewChat: () => void;
}

const MainView: React.FC<MainViewProps> = ({ onSendMessage, isLoading, speechProps, onShowHistory, onStartCall, onNewChat }) => {
    return (
        <div className="bg-brand-bg text-brand-text min-h-screen flex flex-col items-center justify-center p-4 font-sans relative">
            <header className="absolute top-0 left-0 right-0 p-4 sm:p-6 flex justify-between items-center">
                <button onClick={onNewChat} className="p-2 rounded-full bg-brand-surface hover:bg-brand-surface-light transition-colors" aria-label="New Chat">
                    <PlusIcon className="w-6 h-6" />
                </button>
                <div className="flex items-center space-x-2">
                    <button onClick={onShowHistory} className="p-2 rounded-full hover:bg-brand-surface transition-colors" aria-label="History">
                        <HistoryIcon className="w-6 h-6" />
                    </button>
                    <button className="p-2 rounded-full hover:bg-brand-surface transition-colors" aria-label="User Profile">
                        <UserIcon className="w-6 h-6" />
                    </button>
                </div>
            </header>

            <main className="flex flex-col items-center justify-center w-full max-w-3xl px-4">
                <h1 className="text-4xl md:text-6xl font-medium mb-8 text-center text-brand-text">
                    What do you want to explore?
                </h1>
                <MainInput 
                    onSendMessage={onSendMessage} 
                    isLoading={isLoading} 
                    speechProps={{
                        isRecording: speechProps.isListening,
                        onMicClick: speechProps.isListening ? speechProps.stopListening : speechProps.startListening,
                        initialInput: speechProps.transcript,
                        resetTranscript: speechProps.resetTranscript
                    }}
                    onStartCall={onStartCall}
                />
            </main>
        </div>
    );
};

export default MainView;
